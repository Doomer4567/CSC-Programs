import calendar

'''
This class is for a calendar feature that may be implemented in future semesters.
For now it is empty.
You (the student) do not need to do any work here.
'''

class Calendar(object):
    pass


